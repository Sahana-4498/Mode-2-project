package com.pack.IrctcUser.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pack.IrctcUser.Dto.LoginDto;
import com.pack.IrctcUser.Service.UserService;
import com.pack.IrctcUser.model.User;

@RestController
public class UserController {

	@Autowired
	UserService userService;

	@PostMapping("/user/Registration")
	public String UserRegistration(@RequestBody User user) {
		return userService.addUser(user);

	}

	@PutMapping("/user/Login/{userId}")
	public String UserLogin(@RequestBody LoginDto loginDto, @PathVariable("userId") String userId) {
		return userService.userLogin(loginDto, userId);
	}

}
