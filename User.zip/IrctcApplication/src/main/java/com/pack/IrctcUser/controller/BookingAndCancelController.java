package com.pack.IrctcUser.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pack.IrctcUser.Dto.BookingDto;
import com.pack.IrctcUser.Dto.PassengerDto;
import com.pack.IrctcUser.Service.BookingAndCancelService;

@RestController
public class BookingAndCancelController {

	@Autowired
	private BookingAndCancelService bookingService;

	@PostMapping(value = "/user/booking/train")
	public int addBooking(@RequestBody BookingDto bookingDto) {

		return bookingService.bookTrainTicket(bookingDto);
	}

	@PostMapping(value = "/user/add/passenger")
	public List<String> addPassenger(@RequestBody PassengerDto passengerDto) {

		return bookingService.addPassenger(passengerDto);
	}

	@DeleteMapping(value = "/user/cancelTicket/{PNRNumber}")
	public void deletePassenger(@PathVariable(value = "PNRNumber") String pnrNumber) {

		bookingService.cancelTrainTicket(pnrNumber);

	}
}
