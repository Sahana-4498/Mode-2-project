package com.pack.IrctcUser.Service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.pack.IrctcUser.Dto.SearchDto;
import com.pack.IrctcUser.Dto.SearchDto1;
import com.pack.IrctcUser.exception.StationNotFoundException;
import com.pack.IrctcUser.exception.TrainNumberNotFoundException;

@Service
public class SearchService {
	@Autowired
	RestTemplate restTemplate;
	
	public SearchDto getTrainFromTrainNumber(String trainNumber1) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("trainNumber", trainNumber1);
		
		SearchDto result =  restTemplate.getForObject("http://SEARCHAPPLICATION/train/{trainNumber}", SearchDto.class,
				params);
		System.out.println("HI sdfdfvsdf"+result);
		if (result.equals(null)) {
			throw new TrainNumberNotFoundException("Train Number not available");
		}
		return result;
	}

	public SearchDto1 getTrainByFromPlaceAndToPlcaeAndDate(String from, String to, LocalDate date) {
	
		SearchDto1 result1 = restTemplate.getForObject(
				"http://SEARCHAPPLICATION/train/details/{fromPlace}/{toPlace}/{date}", SearchDto1.class, from, to, date);
		if (result1.equals(null)) {
			throw new StationNotFoundException("Station names are not available");
		}
		return result1;
	}
}
